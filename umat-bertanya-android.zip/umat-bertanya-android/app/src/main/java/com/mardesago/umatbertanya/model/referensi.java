package com.mardesago.umatbertanya.model;

/**
 * Created by Dwi Randy Herdinanto on 11/3/2017.
 */

public class referensi {
    private int id_referensi;
    private String deskripsi;

    public int getId_referensi() {
        return id_referensi;
    }

    public void setId_referensi(int id_referensi) {
        this.id_referensi = id_referensi;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }
}
